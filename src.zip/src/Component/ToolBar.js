import React from 'react';


const ToolBar = props =>(
    <header className="navbar">
      <nav className="navbar_toolbar">
          <div className="nav_navigation">
            <ul className="navBar_ul">
              <li><a href="/"> Home </a> </li>
              <li><a href="/">Services </a> </li>
              <li><a href="/">Blog </a> </li>
              <li><a href="/">Contact Us</a> </li>
              <li><a href="/">About Us </a> </li>
            </ul>
          </div>
      </nav>
    </header>
);

export default ToolBar;
